﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace justAttendanceSystem
{
    class getUsers
    {
        private static string myUser;

        public static string MyUser { 
            get => myUser; 
            set => myUser = value;
        }
    }
    
}
