﻿namespace justAttendanceSystem.pal.forms
{
    internal class listView1
    {
    }
}